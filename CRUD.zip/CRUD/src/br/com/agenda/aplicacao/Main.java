package br.com.agenda.aplicacao;

import java.util.Date;

import br.com.agenda.dao.ContatoDAO;
import br.com.agenda.model.Contato;

public class Main {

	public static void main(String[] args) {
		
		Contato contato = new Contato();
		ContatoDAO contatoDao = new ContatoDAO();
		
		/* CADASTRO
		contato.setNome("Jamylle Vitoria");
		contato.setIdade(19);
		contato.setDataCadastro(new Date());	
		contatoDao.save(contato);
		*/
		
		/* ATUALIZADNO
		Contato c1 = new Contato();
		c1.setNome("Maria de Santana");
		c1.setIdade(16);
		c1.setDataCadastro(new Date());
		c1.setId(4); // ID que está no banco
		
		contatoDao.update(c1);
		*/
		
		/*
		//DELETAR o contato pelo ID
		contatoDao.deleteByID(5);
		
		*/
		
		/*
		//Vizualização dos registros do banco de dados TODOS
		
		for(Contato c : contatoDao.getContatos()) {
			System.out.println("Contato: ");
			System.out.println("Nome: " + c.getNome());
			System.out.println("Idade: " + c.getIdade());
			System.out.println("Data de cadastro: " + c.getDataCadastro());
			System.out.println("-------------------------------------------");
		}
		*/
		 
	}

}	

package br.com.agenda.factory;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {

	//nome do usuario do mysql 
	private static final String USERNAME = "root"; 
	
	//senha do banco
	private static final String PASSWORD = "";
	
	//Caminho do banco de dados a porta 3306, nome do banco de dados
	private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/agenda";
	
	/*
	 * Conexão com o banco de dados
	 */
	public static Connection createdConnectionToMySQL() throws Exception{
		//faz com a classe seja carregada pela JVM
		Class.forName("com.mysql.jdbc.Driver");
		
		//Cria a conexão com o banco de dados
		Connection connection = DriverManager.getConnection(DATABASE_URL,USERNAME,PASSWORD);
		
		return connection;
	}
	
	public static void main(String[] args) throws Exception {
		
		//Recuperar a conexão com o banco de dados 
		Connection con = createdConnectionToMySQL();
		
		//testar se a conexão e nula
		if(con != null) {
			
			System.out.println("Conexão obitida!!");
			con.close();
		}
	}
}
